import { render, screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import App from './App'

vi.mock('sweetalert2', () => ({
  default: { fire: vi.fn(() => Promise.resolve()) },
}))

const irA = (ruta) => window.history.pushState({}, '', ruta)

beforeEach(() => irA('/'))

describe('App (flujo completo)', () => {
  it('muestra la página de inicio', () => {
    render(<App />)
    expect(screen.getByRole('link', { name: /ver catálogo/i })).toBeInTheDocument()
  })

  it('agregar el mismo producto dos veces sube la cantidad', async () => {
    irA('/productos')
    render(<App />)
    const boton = screen.getAllByRole('button', { name: /añadir/i })[0]
    await userEvent.click(boton)
    await userEvent.click(boton)
    expect(screen.getByRole('link', { name: /carrito/i })).toHaveTextContent('2')
    await userEvent.click(screen.getByRole('link', { name: /carrito/i }))
    expect(screen.getByText('Tu Carrito de Compras')).toBeInTheDocument()
    expect(screen.getByText(/259\.980/)).toBeInTheDocument()
  })

  it('restar, eliminar y vaciar funcionan en el carrito', async () => {
    irA('/productos')
    render(<App />)
    await userEvent.click(screen.getAllByRole('button', { name: /añadir/i })[0])
    await userEvent.click(screen.getAllByRole('button', { name: /añadir/i })[1])
    await userEvent.click(screen.getByRole('link', { name: /carrito/i }))

    await userEvent.click(screen.getAllByRole('button', { name: '+' })[0])
    await userEvent.click(screen.getAllByRole('button', { name: '-' })[0])
    await userEvent.click(screen.getAllByRole('button', { name: '-' })[0]) // llega a 0 y desaparece
    expect(screen.queryByText('Yamaha F310')).not.toBeInTheDocument()

    await userEvent.click(screen.getAllByRole('button', { name: '🗑️' })[0])
    expect(screen.getByText(/tu carrito está vacío/i)).toBeInTheDocument()

    irA('/productos')
  })

  it('vaciar carrito deja el carrito en cero', async () => {
    irA('/productos')
    render(<App />)
    await userEvent.click(screen.getAllByRole('button', { name: /añadir/i })[0])
    await userEvent.click(screen.getByRole('link', { name: /carrito/i }))
    await userEvent.click(screen.getByRole('button', { name: /vaciar carrito/i }))
    expect(screen.getByText(/tu carrito está vacío/i)).toBeInTheDocument()
  })

  it('un usuario sin sesión no puede entrar a /admin', () => {
    irA('/admin')
    render(<App />)
    expect(screen.getByText('Iniciar Sesión', { selector: 'h3' })).toBeInTheDocument()
  })

  it('el admin entra al panel y puede cerrar sesión', async () => {
    irA('/login')
    render(<App />)
    const campos = document.querySelectorAll('input[type="email"], input[type="password"]')
    await userEvent.type(campos[0], 'admin@sonidovivo.cl')
    await userEvent.type(campos[1], 'admin123')
    await userEvent.click(screen.getByRole('button', { name: 'Ingresar' }))
    expect(await screen.findByText('Panel Admin')).toBeInTheDocument()

    await userEvent.click(screen.getByRole('button', { name: 'Salir' }))
    expect(localStorage.getItem('usuario_sonido_vivo')).toBeNull()
  })

  it('compra completa: carrito, pago e historial', async () => {
    irA('/login')
    render(<App />)
    const login = document.querySelectorAll('input[type="email"], input[type="password"]')
    await userEvent.type(login[0], 'cris@mail.cl')
    await userEvent.type(login[1], 'clave')
    await userEvent.click(screen.getByRole('button', { name: 'Ingresar' }))

    await userEvent.click(screen.getAllByRole('button', { name: /añadir/i })[0])
    await userEvent.click(screen.getByRole('link', { name: /carrito/i }))
    await userEvent.click(screen.getByRole('button', { name: /procesar pago/i }))

    // Ojo: el navbar también tiene un input (el buscador), por eso buscamos solo dentro de <main>
    const campos = document.querySelector('main').querySelectorAll('input')
    await userEvent.type(campos[2], 'Calle 123')
    await userEvent.type(campos[3], '1234567812345678')
    await userEvent.click(screen.getByRole('button', { name: /confirmar pago/i }))

    expect(await screen.findByText(/historial de compras/i)).toBeInTheDocument()
    expect(screen.getByText(/orden #/i)).toBeInTheDocument()
    expect(JSON.parse(localStorage.getItem('carrito_sonido_vivo'))).toEqual([])
  })

  it('el catálogo recuerda el admin: producto nuevo aparece en el catálogo', async () => {
    irA('/login')
    render(<App />)
    const campos = document.querySelectorAll('input[type="email"], input[type="password"]')
    await userEvent.type(campos[0], 'admin@sonidovivo.cl')
    await userEvent.type(campos[1], 'admin123')
    await userEvent.click(screen.getByRole('button', { name: 'Ingresar' }))

    await userEvent.type(await screen.findByPlaceholderText('Nombre'), 'Cajón Peruano')
    await userEvent.type(screen.getByPlaceholderText(/precio/i), '59990')
    await userEvent.click(screen.getByRole('button', { name: /guardar/i }))
    const tabla = screen.getByRole('table')
    expect(within(tabla).getByText('Cajón Peruano')).toBeInTheDocument()

    await userEvent.click(screen.getAllByRole('link', { name: 'Catálogo' })[0])
    expect(screen.getByText('Cajón Peruano')).toBeInTheDocument()
  })

  it('lee el carrito guardado en localStorage al abrir', () => {
    localStorage.setItem('carrito_sonido_vivo', JSON.stringify([{ id: 1, nombre: 'Yamaha F310', precio: 129990, cantidad: 3, imagen: 'a.jpg' }]))
    render(<App />)
    expect(screen.getByRole('link', { name: /carrito/i })).toHaveTextContent('3')
  })

  it('si el localStorage está dañado usa los valores por defecto', () => {
    localStorage.setItem('carrito_sonido_vivo', '{esto no es json')
    render(<App />)
    expect(screen.getByRole('link', { name: /carrito/i })).toHaveTextContent('0')
  })
})
