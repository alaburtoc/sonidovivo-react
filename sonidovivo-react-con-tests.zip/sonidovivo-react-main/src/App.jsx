import { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { listaProductosInicial } from './data/productos'
import Navbar from './components/Navbar'
import Inicio from './components/Inicio'
import Productos from './components/Productos'
import DetalleProducto from './components/DetalleProducto'
import Carrito from './components/Carrito'
import Pago from './components/Pago'
import Historial from './components/Historial'
import Login from './components/Login'
import Registro from './components/Registro'
import Admin from './components/Admin'
import Nosotros from './components/Nosotros'
import Contacto from './components/Contacto'
import Footer from './components/Footer'
import './App.css'

// Lee algo guardado en el navegador (localStorage). Si no hay nada, usa el valor por defecto.
const leerGuardado = (clave, porDefecto) => {
  try {
    const guardado = localStorage.getItem(clave)
    return guardado ? JSON.parse(guardado) : porDefecto
  } catch {
    return porDefecto
  }
}

export default function App() {
  const [productos, setProductos] = useState(() => leerGuardado('productos_sonido_vivo', listaProductosInicial))
  const [carrito, setCarrito] = useState(() => leerGuardado('carrito_sonido_vivo', []))
  const [pedidos, setPedidos] = useState(() => leerGuardado('pedidos_sonido_vivo', []))
  const [usuario, setUsuario] = useState(() => leerGuardado('usuario_sonido_vivo', null))

  // Cada vez que cambian, se guardan en el navegador
  useEffect(() => { localStorage.setItem('productos_sonido_vivo', JSON.stringify(productos)) }, [productos])
  useEffect(() => { localStorage.setItem('carrito_sonido_vivo', JSON.stringify(carrito)) }, [carrito])
  useEffect(() => { localStorage.setItem('pedidos_sonido_vivo', JSON.stringify(pedidos)) }, [pedidos])

  // ---------- CARRITO ----------
  const agregarAlCarrito = (prod) => {
    const existe = carrito.find(item => item.id === prod.id)
    if (existe) {
      // Si ya está, solo le sumamos 1 a la cantidad
      setCarrito(carrito.map(item =>
        item.id === prod.id ? { ...item, cantidad: item.cantidad + 1 } : item
      ))
    } else {
      // Si no está, lo agregamos con cantidad 1
      setCarrito([...carrito, { ...prod, cantidad: 1 }])
    }
  }

  const restarCantidad = (id) => {
    setCarrito(
      carrito
        .map(item => item.id === id ? { ...item, cantidad: item.cantidad - 1 } : item)
        .filter(item => item.cantidad > 0)
    )
  }

  const eliminarDelCarrito = (id) => setCarrito(carrito.filter(item => item.id !== id))
  const vaciarCarrito = () => setCarrito([])

  // ---------- PEDIDOS ----------
  const agregarPedido = (pedido) => setPedidos([...pedidos, pedido])

  // ---------- SESIÓN ----------
  const cerrarSesion = () => {
    setUsuario(null)
    localStorage.removeItem('usuario_sonido_vivo')
  }

  // El navbar muestra la suma de cantidades (no solo cuántos productos distintos)
  const cantidadCarrito = carrito.reduce((suma, item) => suma + item.cantidad, 0)

  return (
    <BrowserRouter>
      <div className="d-flex flex-column min-vh-100">
        <Navbar cantidadCarrito={cantidadCarrito} usuario={usuario} cerrarSesion={cerrarSesion} />

        <main className="flex-grow-1 container">
          <Routes>
            <Route path="/" element={<Inicio />} />
            <Route path="/productos" element={<Productos productos={productos} agregarAlCarrito={agregarAlCarrito} />} />
            <Route path="/producto/:id" element={<DetalleProducto productos={productos} agregarAlCarrito={agregarAlCarrito} />} />
            <Route path="/carrito" element={
              <Carrito
                carrito={carrito}
                agregarAlCarrito={agregarAlCarrito}
                restarCantidad={restarCantidad}
                eliminarDelCarrito={eliminarDelCarrito}
                vaciarCarrito={vaciarCarrito}
              />
            } />
            <Route path="/pago" element={
              <Pago carrito={carrito} vaciarCarrito={vaciarCarrito} agregarPedido={agregarPedido} usuario={usuario} />
            } />
            <Route path="/historial" element={<Historial pedidos={pedidos} usuario={usuario} />} />
            <Route path="/login" element={<Login setUsuario={setUsuario} />} />
            <Route path="/registro" element={<Registro setUsuario={setUsuario} />} />
            {/* Solo entra el admin; si no, lo mandamos al login */}
            <Route path="/admin" element={
              usuario?.rol === 'admin'
                ? <Admin productos={productos} setProductos={setProductos} />
                : <Navigate to="/login" replace />
            } />
            <Route path="/nosotros" element={<Nosotros />} />
            <Route path="/contacto" element={<Contacto />} />
          </Routes>
        </main>

        <Footer />
      </div>
    </BrowserRouter>
  )
}
