import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import Inicio from './Inicio'
import Nosotros from './Nosotros'
import Contacto from './Contacto'
import Footer from './Footer'

describe('Páginas informativas', () => {
  it('Inicio muestra el título y los botones', () => {
    render(<MemoryRouter><Inicio /></MemoryRouter>)
    expect(screen.getByRole('link', { name: /ver catálogo/i })).toHaveAttribute('href', '/productos')
  })

  it('Nosotros muestra la información de la tienda', () => {
    render(<Nosotros />)
    expect(screen.getByText(/sobre sonido vivo/i)).toBeInTheDocument()
  })

  it('Footer muestra los enlaces', () => {
    render(<MemoryRouter><Footer /></MemoryRouter>)
    expect(screen.getAllByRole('link', { name: /catálogo/i }).length).toBeGreaterThan(0)
  })

  it('Contacto muestra mensaje de gracias al enviar el formulario', async () => {
    render(<Contacto />)
    const campos = document.querySelectorAll('input, textarea')
    await userEvent.type(campos[0], 'Cristobal')
    await userEvent.type(campos[1], 'cris@mail.cl')
    await userEvent.type(campos[2], 'Hola, quiero cotizar.')
    await userEvent.click(screen.getByRole('button', { name: /enviar mensaje/i }))
    expect(screen.getByText(/gracias por comunicarte/i)).toBeInTheDocument()
  })
})
