import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Routes, Route } from 'react-router-dom'
import Swal from 'sweetalert2'
import Pago from './Pago'
import { itemCarrito } from '../tests/datos'

// Reemplazamos SweetAlert por uno "falso" que responde al tiro
vi.mock('sweetalert2', () => ({
  default: { fire: vi.fn(() => Promise.resolve()) },
}))

const mostrar = (props) =>
  render(
    <MemoryRouter initialEntries={['/pago']}>
      <Routes>
        <Route path="/pago" element={<Pago {...props} />} />
        <Route path="/historial" element={<h1>Página historial</h1>} />
      </Routes>
    </MemoryRouter>
  )

describe('Pago', () => {
  it('muestra el monto total', () => {
    mostrar({ carrito: [itemCarrito], vaciarCarrito: vi.fn(), agregarPedido: vi.fn(), usuario: null })
    expect(screen.getByText(/259\.980/)).toBeInTheDocument()
  })

  it('precarga nombre y correo si hay usuario', () => {
    mostrar({
      carrito: [itemCarrito], vaciarCarrito: vi.fn(), agregarPedido: vi.fn(),
      usuario: { nombre: 'Cristobal', email: 'cris@mail.cl' },
    })
    expect(screen.getByDisplayValue('Cristobal')).toBeInTheDocument()
    expect(screen.getByDisplayValue('cris@mail.cl')).toBeInTheDocument()
  })

  it('al confirmar crea el pedido, vacía el carrito y va al historial', async () => {
    const agregarPedido = vi.fn()
    const vaciarCarrito = vi.fn()
    const { container } = render(
      <MemoryRouter initialEntries={['/pago']}>
        <Routes>
          <Route path="/pago" element={<Pago carrito={[itemCarrito]} vaciarCarrito={vaciarCarrito} agregarPedido={agregarPedido} usuario={null} />} />
          <Route path="/historial" element={<h1>Página historial</h1>} />
        </Routes>
      </MemoryRouter>
    )
    const campos = container.querySelectorAll('input')
    await userEvent.type(campos[0], 'Cristobal')
    await userEvent.type(campos[1], 'cris@mail.cl')
    await userEvent.type(campos[2], 'Calle 123')
    await userEvent.type(campos[3], '1234567812345678')
    await userEvent.click(screen.getByRole('button', { name: /confirmar pago/i }))

    expect(agregarPedido).toHaveBeenCalledTimes(1)
    expect(agregarPedido.mock.calls[0][0]).toMatchObject({
      clienteNombre: 'Cristobal', clienteEmail: 'cris@mail.cl', total: 259980,
    })
    expect(vaciarCarrito).toHaveBeenCalled()
    expect(Swal.fire).toHaveBeenCalled()
    expect(await screen.findByText('Página historial')).toBeInTheDocument()
  })

  it('no crea pedido si el carrito está vacío', async () => {
    const agregarPedido = vi.fn()
    const { container } = render(
      <MemoryRouter>
        <Pago carrito={[]} vaciarCarrito={vi.fn()} agregarPedido={agregarPedido} usuario={{ nombre: 'A', email: 'a@a.cl' }} />
      </MemoryRouter>
    )
    const campos = container.querySelectorAll('input')
    await userEvent.type(campos[2], 'Calle 1')
    await userEvent.type(campos[3], '1234567812345678')
    await userEvent.click(screen.getByRole('button', { name: /confirmar pago/i }))
    expect(agregarPedido).not.toHaveBeenCalled()
  })
})
