import { render, screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import Historial from './Historial'
import { itemCarrito } from '../tests/datos'

const pedido = (id, email) => ({
  id, fecha: '01-01-2026', clienteNombre: 'Alguien', clienteEmail: email,
  total: 259980, items: [itemCarrito],
})
const pedidos = [pedido(111, 'cris@mail.cl'), pedido(222, 'otro@mail.cl')]
const mostrar = (usuario) =>
  render(<MemoryRouter><Historial pedidos={pedidos} usuario={usuario} /></MemoryRouter>)

describe('Historial', () => {
  it('pide iniciar sesión si no hay usuario', () => {
    mostrar(null)
    expect(screen.getByText(/inicia sesión para ver tu historial/i)).toBeInTheDocument()
  })

  it('el cliente solo ve sus pedidos', () => {
    mostrar({ nombre: 'Cris', email: 'cris@mail.cl', rol: 'cliente' })
    expect(screen.getByText(/orden #111/i)).toBeInTheDocument()
    expect(screen.queryByText(/orden #222/i)).not.toBeInTheDocument()
  })

  it('el admin ve todos los pedidos', () => {
    mostrar({ nombre: 'Admin', email: 'admin@sonidovivo.cl', rol: 'admin' })
    expect(screen.getByText(/orden #111/i)).toBeInTheDocument()
    expect(screen.getByText(/orden #222/i)).toBeInTheDocument()
  })

  it('avisa si el cliente no tiene pedidos', () => {
    mostrar({ nombre: 'Nuevo', email: 'nuevo@mail.cl', rol: 'cliente' })
    expect(screen.getByText(/no tienes pedidos registrados/i)).toBeInTheDocument()
  })
})
