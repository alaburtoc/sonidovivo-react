import { render, screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import Admin from './Admin'
import { productoA, productoB } from '../tests/datos'

const mostrar = (setProductos = vi.fn()) => {
  render(<Admin productos={[productoA, productoB]} setProductos={setProductos} />)
  return setProductos
}

describe('Admin', () => {
  it('lista el inventario', () => {
    mostrar()
    expect(screen.getByText(/inventario \(2\)/i)).toBeInTheDocument()
    expect(screen.getByText('Yamaha F310')).toBeInTheDocument()
  })

  it('agrega un producto nuevo con stock', async () => {
    const setProductos = mostrar()
    await userEvent.type(screen.getByPlaceholderText('Nombre'), 'Cajón Peruano')
    await userEvent.selectOptions(screen.getByRole('combobox'), 'Percusión')
    await userEvent.type(screen.getByPlaceholderText(/precio/i), '59990')
    await userEvent.click(screen.getByRole('button', { name: /guardar/i }))

    expect(setProductos).toHaveBeenCalledTimes(1)
    const nuevaLista = setProductos.mock.calls[0][0]
    expect(nuevaLista).toHaveLength(3)
    expect(nuevaLista[2]).toMatchObject({
      nombre: 'Cajón Peruano', categoria: 'Percusión', precio: 59990, stock: true,
    })
  })

  it('guarda la URL de imagen y la descripción por defecto', async () => {
    const setProductos = mostrar()
    await userEvent.type(screen.getByPlaceholderText('Nombre'), 'Micrófono')
    await userEvent.type(screen.getByPlaceholderText(/precio/i), '30000')
    await userEvent.type(screen.getByPlaceholderText(/url imagen/i), 'https://ejemplo.cl/foto.jpg')
    await userEvent.click(screen.getByRole('button', { name: /guardar/i }))
    expect(setProductos.mock.calls[0][0][2]).toMatchObject({
      imagen: 'https://ejemplo.cl/foto.jpg',
      descripcion: 'Producto profesional de audio.',
    })
  })

  it('cambia el stock de un producto', async () => {
    const setProductos = mostrar()
    await userEvent.click(screen.getAllByRole('button', { name: 'Disponible' })[0])
    const nuevaLista = setProductos.mock.calls[0][0]
    expect(nuevaLista[0].stock).toBe(false)
    expect(nuevaLista[1].stock).toBe(true)
  })

  it('elimina un producto si se confirma', async () => {
    vi.spyOn(window, 'confirm').mockReturnValue(true)
    const setProductos = mostrar()
    const fila = screen.getByText('Yamaha F310').closest('tr')
    await userEvent.click(within(fila).getByRole('button', { name: /eliminar/i }))
    expect(setProductos).toHaveBeenCalledWith([productoB])
  })

  it('no elimina si se cancela', async () => {
    vi.spyOn(window, 'confirm').mockReturnValue(false)
    const setProductos = mostrar()
    const fila = screen.getByText('Yamaha F310').closest('tr')
    await userEvent.click(within(fila).getByRole('button', { name: /eliminar/i }))
    expect(setProductos).not.toHaveBeenCalled()
  })
})
