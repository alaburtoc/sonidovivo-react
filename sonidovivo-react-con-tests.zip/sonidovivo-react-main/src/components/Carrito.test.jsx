import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import Carrito from './Carrito'
import { itemCarrito } from '../tests/datos'

const props = () => ({
  carrito: [itemCarrito],
  agregarAlCarrito: vi.fn(),
  restarCantidad: vi.fn(),
  eliminarDelCarrito: vi.fn(),
  vaciarCarrito: vi.fn(),
})

const mostrar = (p) => render(<MemoryRouter><Carrito {...p} /></MemoryRouter>)

describe('Carrito', () => {
  it('muestra mensaje cuando está vacío', () => {
    mostrar({ ...props(), carrito: [] })
    expect(screen.getByText(/tu carrito está vacío/i)).toBeInTheDocument()
  })

  it('muestra el producto, la cantidad y el total', () => {
    mostrar(props())
    expect(screen.getByText('Yamaha F310')).toBeInTheDocument()
    expect(screen.getByText('2')).toBeInTheDocument()
    // 129990 x 2 = 259980
    expect(screen.getByText(/259\.980/)).toBeInTheDocument()
  })

  it('llama a las funciones al apretar +, -, eliminar y vaciar', async () => {
    const p = props()
    mostrar(p)
    await userEvent.click(screen.getByRole('button', { name: '+' }))
    await userEvent.click(screen.getByRole('button', { name: '-' }))
    await userEvent.click(screen.getByRole('button', { name: '🗑️' }))
    await userEvent.click(screen.getByRole('button', { name: /vaciar carrito/i }))
    expect(p.agregarAlCarrito).toHaveBeenCalledWith(itemCarrito)
    expect(p.restarCantidad).toHaveBeenCalledWith(1)
    expect(p.eliminarDelCarrito).toHaveBeenCalledWith(1)
    expect(p.vaciarCarrito).toHaveBeenCalled()
  })

  it('el botón Procesar Pago está disponible', () => {
    mostrar(props())
    expect(screen.getByRole('button', { name: /procesar pago/i })).toBeInTheDocument()
  })
})
