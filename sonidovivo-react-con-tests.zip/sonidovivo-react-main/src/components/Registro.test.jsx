import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Routes, Route } from 'react-router-dom'
import Registro from './Registro'

describe('Registro', () => {
  it('crea un usuario cliente y va al catálogo', async () => {
    const setUsuario = vi.fn()
    render(
      <MemoryRouter initialEntries={['/registro']}>
        <Routes>
          <Route path="/registro" element={<Registro setUsuario={setUsuario} />} />
          <Route path="/productos" element={<h1>Página productos</h1>} />
        </Routes>
      </MemoryRouter>
    )
    const campos = document.querySelectorAll('input')
    await userEvent.type(campos[0], 'Cristobal')
    await userEvent.type(campos[1], 'cris@mail.cl')
    await userEvent.type(campos[2], 'clave123')
    await userEvent.click(screen.getByRole('button', { name: /registrarse/i }))

    expect(setUsuario).toHaveBeenCalledWith({ nombre: 'Cristobal', email: 'cris@mail.cl', rol: 'cliente' })
    expect(localStorage.getItem('usuario_sonido_vivo')).toContain('cris@mail.cl')
    expect(await screen.findByText('Página productos')).toBeInTheDocument()
  })
})
