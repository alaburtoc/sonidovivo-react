import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import Productos from './Productos'
import { productoA, productoB, productoSinStock } from '../tests/datos'

const lista = [productoA, productoB, productoSinStock]
const mostrar = (agregar = vi.fn()) =>
  render(<MemoryRouter><Productos productos={lista} agregarAlCarrito={agregar} /></MemoryRouter>)

describe('Productos', () => {
  it('muestra todos los productos al inicio', () => {
    mostrar()
    expect(screen.getByText('Yamaha F310')).toBeInTheDocument()
    expect(screen.getByText('Fender Stratocaster')).toBeInTheDocument()
    expect(screen.getByText('Marshall DSL40CR')).toBeInTheDocument()
  })

  it('filtra por nombre al escribir en el buscador', async () => {
    mostrar()
    await userEvent.type(screen.getByPlaceholderText(/buscar por nombre/i), 'fender')
    expect(screen.getByText('Fender Stratocaster')).toBeInTheDocument()
    expect(screen.queryByText('Yamaha F310')).not.toBeInTheDocument()
  })

  it('filtra por categoría', async () => {
    mostrar()
    await userEvent.selectOptions(screen.getByRole('combobox'), 'Audio Profesional')
    expect(screen.getByText('Marshall DSL40CR')).toBeInTheDocument()
    expect(screen.queryByText('Yamaha F310')).not.toBeInTheDocument()
  })

  it('agrega al carrito al apretar Añadir', async () => {
    const agregar = vi.fn()
    mostrar(agregar)
    await userEvent.click(screen.getAllByRole('button', { name: /añadir/i })[0])
    expect(agregar).toHaveBeenCalledWith(productoA)
  })

  it('muestra "Sin Stock" y no deja añadir ese producto', () => {
    mostrar()
    expect(screen.getByText('Sin Stock')).toBeInTheDocument()
    expect(screen.getAllByRole('button', { name: /añadir/i })).toHaveLength(2)
  })
})
