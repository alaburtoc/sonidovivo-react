// Datos de ejemplo que reutilizamos en varios tests
export const productoA = {
  id: 1, nombre: 'Yamaha F310', categoria: 'Guitarras Acústicas',
  precio: 129990, stock: true, imagen: 'a.jpg', descripcion: 'Guitarra para iniciar.'
}
export const productoB = {
  id: 2, nombre: 'Fender Stratocaster', categoria: 'Guitarras Eléctricas',
  precio: 849900, stock: true, imagen: 'b.jpg', descripcion: 'Sonido clásico.'
}
export const productoSinStock = {
  id: 3, nombre: 'Marshall DSL40CR', categoria: 'Audio Profesional',
  precio: 729990, stock: false, imagen: 'c.jpg', descripcion: 'Combo valvular.'
}
export const itemCarrito = { ...productoA, cantidad: 2 }
