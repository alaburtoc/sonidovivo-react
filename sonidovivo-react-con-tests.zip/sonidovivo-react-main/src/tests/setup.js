import '@testing-library/jest-dom/vitest'
import { afterEach } from 'vitest'
import { cleanup } from '@testing-library/react'

// Después de cada test limpiamos la pantalla simulada y el localStorage
afterEach(() => {
  cleanup()
  localStorage.clear()
})
