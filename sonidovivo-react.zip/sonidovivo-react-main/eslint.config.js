import js from '@eslint/js'
import globals from 'globals'
import reactHooks from 'eslint-plugin-react-hooks'
import reactRefresh from 'eslint-plugin-react-refresh'
import { defineConfig, globalIgnores } from 'eslint/config'

export default defineConfig([
  globalIgnores(['dist', 'coverage']),
  {
    files: ['**/*.{js,jsx}'],
    extends: [
      js.configs.recommended,
      reactHooks.configs.flat.recommended,
      reactRefresh.configs.vite,
    ],
    languageOptions: {
      globals: globals.browser,
      parserOptions: { ecmaFeatures: { jsx: true } },
    },
  },
  {
    // Archivos de prueba: Jasmine aporta describe, it, expect, spyOn, etc.
    files: ['**/*.test.{js,jsx}', 'src/tests/**/*.js'],
    languageOptions: { globals: { ...globals.browser, ...globals.jasmine } },
  },
  {
    // Configuración de Karma: corre en Node (module.exports)
    files: ['karma.conf.cjs'],
    languageOptions: { globals: globals.node, sourceType: 'commonjs' },
  },
])
