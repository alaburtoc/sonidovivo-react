// Configuración de Karma: es el "corredor" que ejecuta los tests de Jasmine.
module.exports = (config) => {
  config.set({
    frameworks: ['jasmine', 'webpack'],          // Jasmine escribe los tests, webpack los empaqueta
    files: ['src/tests/index.js'],               // archivo de entrada: carga todos los *.test.jsx
    preprocessors: { 'src/tests/index.js': ['webpack'] },

    webpack: {
      mode: 'development',
      module: {
        rules: [
          // El proyecto es "type: module": le decimos a webpack que acepte imports sin la extensión (./setup)
          { test: /\.m?jsx?$/, resolve: { fullySpecified: false } },
          {
            test: /\.jsx?$/,
            exclude: /node_modules/,
            use: {
              loader: 'babel-loader',              // convierte JSX a JavaScript normal
              options: {
                presets: [
                  ['@babel/preset-env', { targets: { chrome: '100' } }],
                  ['@babel/preset-react', { runtime: 'automatic' }],
                ],
                // istanbul mide qué líneas se ejecutan (cobertura), sin contar los tests
                plugins: [['istanbul', { exclude: ['src/tests/**', '**/*.test.jsx', '**/*.test.js'] }]],
              },
            },
          },
          { test: /\.css$/, use: ['style-loader', 'css-loader'] },
        ],
      },
      resolve: { extensions: ['.js', '.jsx'] },
    },

    browsers: ['jsdom'],                          // navegador simulado (no necesita Chrome)
    reporters: ['spec', 'coverage'],
    coverageReporter: {
      dir: 'coverage',
      reporters: [{ type: 'text' }, { type: 'html' }, { type: 'lcov' }],
      check: { global: { statements: 80, branches: 80, functions: 80, lines: 80 } }, // exige 80%
    },

    plugins: [
      'karma-jasmine', 'karma-webpack', 'karma-jsdom-launcher',
      'karma-coverage', 'karma-spec-reporter',
    ],
    singleRun: true,
  })
}
