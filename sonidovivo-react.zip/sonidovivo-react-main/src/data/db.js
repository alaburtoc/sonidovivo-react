// "Base de datos" simulada: guarda los productos en el navegador (localStorage).
// Aquí está el CRUD: Crear, Leer, Actualizar y Eliminar.
import { listaProductosInicial } from './productos'

export const CLAVE_PRODUCTOS = 'productos_sonido_vivo'

// LEER todos los productos (si no hay nada guardado, usa la lista inicial)
export const leerProductos = () => {
  try {
    const guardado = localStorage.getItem(CLAVE_PRODUCTOS)
    return guardado ? JSON.parse(guardado) : listaProductosInicial
  } catch {
    return listaProductosInicial
  }
}

const guardarProductos = (lista) => {
  localStorage.setItem(CLAVE_PRODUCTOS, JSON.stringify(lista))
}

// LEER un solo producto por su id
export const obtenerProducto = (id) => leerProductos().find(p => p.id === Number(id))

// CREAR un producto nuevo (le inventa un id que no se repita)
export const crearProducto = (datos) => {
  const lista = leerProductos()
  const nuevo = { stock: true, ...datos, id: Date.now() }
  guardarProductos([...lista, nuevo])
  return nuevo
}

// ACTUALIZAR: cambia solo los campos que le pasamos
export const actualizarProducto = (id, cambios) => {
  const lista = leerProductos().map(p => (p.id === id ? { ...p, ...cambios } : p))
  guardarProductos(lista)
  return lista.find(p => p.id === id)
}

// ELIMINAR un producto
export const eliminarProducto = (id) => {
  guardarProductos(leerProductos().filter(p => p.id !== id))
}
