import {
  leerProductos, obtenerProducto, crearProducto,
  actualizarProducto, eliminarProducto, CLAVE_PRODUCTOS,
} from './db'
import { listaProductosInicial } from './productos'
import { productoA, productoB } from '../tests/datos'

// Estos tests prueban la lógica pura del CRUD, sin pantalla (sin React)
describe('db.js (CRUD de productos)', () => {
  beforeEach(() => {
    localStorage.setItem(CLAVE_PRODUCTOS, JSON.stringify([productoA, productoB]))
  })

  it('LEER: devuelve los productos guardados', () => {
    expect(leerProductos()).toEqual([productoA, productoB])
  })

  it('LEER: si no hay nada guardado devuelve la lista inicial', () => {
    localStorage.clear()
    expect(leerProductos()).toEqual(listaProductosInicial)
  })

  it('LEER: si lo guardado está dañado devuelve la lista inicial', () => {
    localStorage.setItem(CLAVE_PRODUCTOS, '{no es json')
    expect(leerProductos()).toEqual(listaProductosInicial)
  })

  it('LEER UNO: encuentra un producto por id (aunque el id venga como texto)', () => {
    expect(obtenerProducto('2').nombre).toBe('Fender Stratocaster')
  })

  it('LEER UNO: devuelve undefined si no existe', () => {
    expect(obtenerProducto(999)).toBeUndefined()
  })

  it('CREAR: agrega el producto, le pone id y stock, y queda guardado', () => {
    const nuevo = crearProducto({ nombre: 'Cajón', precio: 1000 })
    expect(nuevo.id).toEqual(jasmine.any(Number))
    expect(nuevo.stock).toBe(true)
    expect(leerProductos().length).toBe(3)
  })

  it('ACTUALIZAR: cambia solo los campos indicados', () => {
    const actualizado = actualizarProducto(1, { precio: 5000 })
    expect(actualizado.precio).toBe(5000)
    expect(actualizado.nombre).toBe('Yamaha F310')
    expect(obtenerProducto(1).precio).toBe(5000)
  })

  it('ELIMINAR: quita el producto de la lista', () => {
    eliminarProducto(1)
    expect(leerProductos().map(p => p.id)).toEqual([2])
  })
})
