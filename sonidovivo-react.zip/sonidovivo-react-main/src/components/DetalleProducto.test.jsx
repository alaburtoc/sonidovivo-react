import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Routes, Route } from 'react-router-dom'
import DetalleProducto from './DetalleProducto'
import { productoA } from '../tests/datos'

const mostrar = (ruta, agregar = jasmine.createSpy()) =>
  render(
    <MemoryRouter initialEntries={[ruta]}>
      <Routes>
        <Route path="/producto/:id" element={<DetalleProducto productos={[productoA]} agregarAlCarrito={agregar} />} />
        <Route path="/productos" element={<h1>Página catálogo</h1>} />
      </Routes>
    </MemoryRouter>
  )

describe('DetalleProducto', () => {
  it('muestra los datos del producto', () => {
    mostrar('/producto/1')
    expect(screen.getByText('Yamaha F310')).toBeInTheDocument()
    expect(screen.getByText('Guitarra para iniciar.')).toBeInTheDocument()
  })

  it('agrega al carrito', async () => {
    const agregar = jasmine.createSpy()
    mostrar('/producto/1', agregar)
    await userEvent.click(screen.getByRole('button', { name: /agregar al carrito/i }))
    expect(agregar).toHaveBeenCalledWith(productoA)
  })

  it('el botón Volver lleva al catálogo', async () => {
    mostrar('/producto/1')
    await userEvent.click(screen.getByRole('button', { name: /volver/i }))
    expect(screen.getByText('Página catálogo')).toBeInTheDocument()
  })

  it('muestra error si el producto no existe y permite volver', async () => {
    mostrar('/producto/999')
    expect(screen.getByText(/producto no encontrado/i)).toBeInTheDocument()
    await userEvent.click(screen.getByRole('button', { name: /volver al catálogo/i }))
    expect(screen.getByText('Página catálogo')).toBeInTheDocument()
  })
})
