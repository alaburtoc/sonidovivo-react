import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import Navbar from './Navbar'

const mostrar = (props) => render(<MemoryRouter><Navbar {...props} /></MemoryRouter>)

describe('Navbar', () => {
  it('sin sesión muestra Ingresar y no muestra Admin', () => {
    mostrar({ cantidadCarrito: 0, usuario: null })
    expect(screen.getByRole('link', { name: 'Ingresar' })).toBeInTheDocument()
    expect(screen.queryByRole('link', { name: 'Admin' })).not.toBeInTheDocument()
    expect(screen.queryByText('Mis Compras')).not.toBeInTheDocument()
  })

  it('muestra la cantidad del carrito', () => {
    mostrar({ cantidadCarrito: 5, usuario: null })
    expect(screen.getByText('5')).toBeInTheDocument()
  })

  it('con cliente muestra su nombre y Mis Compras', () => {
    mostrar({ cantidadCarrito: 0, usuario: { nombre: 'Cris', rol: 'cliente' } })
    expect(screen.getByText('Cris')).toBeInTheDocument()
    expect(screen.getByText('Mis Compras')).toBeInTheDocument()
    expect(screen.queryByRole('link', { name: 'Admin' })).not.toBeInTheDocument()
  })

  it('con admin muestra el enlace Admin', () => {
    mostrar({ cantidadCarrito: 0, usuario: { nombre: 'Administrador', rol: 'admin' } })
    expect(screen.getByRole('link', { name: 'Admin' })).toBeInTheDocument()
  })

  it('el botón Salir llama a cerrarSesion', async () => {
    const cerrarSesion = jasmine.createSpy()
    mostrar({ cantidadCarrito: 0, usuario: { nombre: 'Cris', rol: 'cliente' }, cerrarSesion })
    await userEvent.click(screen.getByRole('button', { name: 'Salir' }))
    expect(cerrarSesion).toHaveBeenCalled()
  })

  it('el buscador no recarga la página al enviar', async () => {
    mostrar({ cantidadCarrito: 0, usuario: null })
    await userEvent.type(screen.getByPlaceholderText(/buscar equipos/i), 'guitarra{enter}')
    expect(screen.getByPlaceholderText(/buscar equipos/i)).toHaveValue('guitarra')
  })
})
