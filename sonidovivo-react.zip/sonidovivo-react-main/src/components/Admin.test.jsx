import { render, screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import Admin from './Admin'
import { leerProductos } from '../data/db'
import { productoA, productoB } from '../tests/datos'

// Guardamos 2 productos de ejemplo en la "base de datos" y mostramos el panel
const mostrar = () => {
  localStorage.setItem('productos_sonido_vivo', JSON.stringify([productoA, productoB]))
  const alCambiar = jasmine.createSpy('alCambiar')
  render(<Admin productos={leerProductos()} alCambiar={alCambiar} />)
  return alCambiar
}

describe('Admin', () => {
  it('lista el inventario', () => {
    mostrar()
    expect(screen.getByText(/inventario \(2\)/i)).toBeInTheDocument()
    expect(screen.getByText('Yamaha F310')).toBeInTheDocument()
  })

  it('CREAR: agrega un producto nuevo con stock y avisa a App', async () => {
    const alCambiar = mostrar()
    await userEvent.type(screen.getByPlaceholderText('Nombre'), 'Cajón Peruano')
    await userEvent.selectOptions(screen.getByRole('combobox'), 'Percusión')
    await userEvent.type(screen.getByPlaceholderText(/precio/i), '59990')
    await userEvent.click(screen.getByRole('button', { name: /guardar/i }))

    const lista = leerProductos()
    expect(lista.length).toBe(3)
    expect(lista[2]).toEqual(jasmine.objectContaining({
      nombre: 'Cajón Peruano', categoria: 'Percusión', precio: 59990, stock: true,
    }))
    expect(alCambiar).toHaveBeenCalledTimes(1)
  })

  it('CREAR: usa una imagen por defecto si no se escribe URL', async () => {
    mostrar()
    await userEvent.type(screen.getByPlaceholderText('Nombre'), 'Micrófono')
    await userEvent.type(screen.getByPlaceholderText(/precio/i), '30000')
    await userEvent.click(screen.getByRole('button', { name: /guardar/i }))
    expect(leerProductos()[2].imagen).toContain('unsplash')
  })

  it('CREAR: guarda la URL de imagen que escribe el admin', async () => {
    mostrar()
    await userEvent.type(screen.getByPlaceholderText('Nombre'), 'Micrófono')
    await userEvent.type(screen.getByPlaceholderText(/precio/i), '30000')
    await userEvent.type(screen.getByPlaceholderText(/url imagen/i), 'https://ejemplo.cl/foto.jpg')
    await userEvent.click(screen.getByRole('button', { name: /guardar/i }))
    expect(leerProductos()[2].imagen).toBe('https://ejemplo.cl/foto.jpg')
  })

  it('ACTUALIZAR: Editar carga el producto en el formulario y Actualizar guarda el cambio', async () => {
    const alCambiar = mostrar()
    const fila = screen.getByText('Yamaha F310').closest('tr')
    await userEvent.click(within(fila).getByRole('button', { name: /editar/i }))

    expect(screen.getByText('Editar Producto')).toBeInTheDocument()
    const nombre = screen.getByPlaceholderText('Nombre')
    expect(nombre).toHaveValue('Yamaha F310')

    await userEvent.clear(nombre)
    await userEvent.type(nombre, 'Yamaha F310 Nueva')
    await userEvent.click(screen.getByRole('button', { name: /actualizar/i }))

    expect(leerProductos()[0].nombre).toBe('Yamaha F310 Nueva')
    expect(leerProductos().length).toBe(2)
    expect(alCambiar).toHaveBeenCalled()
    expect(screen.getByText('Nuevo Producto')).toBeInTheDocument() // volvió al modo crear
  })

  it('Cancelar sale del modo edición sin guardar nada', async () => {
    mostrar()
    const fila = screen.getByText('Yamaha F310').closest('tr')
    await userEvent.click(within(fila).getByRole('button', { name: /editar/i }))
    await userEvent.click(screen.getByRole('button', { name: /cancelar/i }))
    expect(screen.getByText('Nuevo Producto')).toBeInTheDocument()
    expect(screen.getByPlaceholderText('Nombre')).toHaveValue('')
    expect(leerProductos()[0].nombre).toBe('Yamaha F310')
  })

  it('ACTUALIZAR: cambia el stock de un producto', async () => {
    mostrar()
    await userEvent.click(screen.getAllByRole('button', { name: 'Disponible' })[0])
    expect(leerProductos()[0].stock).toBe(false)
    expect(leerProductos()[1].stock).toBe(true)
  })

  it('ELIMINAR: borra el producto si se confirma', async () => {
    spyOn(window, 'confirm').and.returnValue(true)
    const alCambiar = mostrar()
    const fila = screen.getByText('Yamaha F310').closest('tr')
    await userEvent.click(within(fila).getByRole('button', { name: /eliminar/i }))
    expect(leerProductos().map(p => p.id)).toEqual([productoB.id])
    expect(alCambiar).toHaveBeenCalled()
  })

  it('ELIMINAR: no borra nada si se cancela', async () => {
    spyOn(window, 'confirm').and.returnValue(false)
    const alCambiar = mostrar()
    const fila = screen.getByText('Yamaha F310').closest('tr')
    await userEvent.click(within(fila).getByRole('button', { name: /eliminar/i }))
    expect(leerProductos().length).toBe(2)
    expect(alCambiar).not.toHaveBeenCalled()
  })
})
