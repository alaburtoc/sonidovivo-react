import { useState } from 'react'
import { crearProducto, actualizarProducto, eliminarProducto } from '../data/db'

const FORMULARIO_VACIO = { nombre: '', categoria: 'Guitarras Acústicas', precio: '', imagen: '' }

// Props: productos (la lista a mostrar) y alCambiar (función para avisar a App que refresque)
export default function Admin({ productos, alCambiar }) {
  const [formulario, setFormulario] = useState(FORMULARIO_VACIO)
  const [editandoId, setEditandoId] = useState(null) // null = estamos creando; con id = estamos editando

  const guardar = (e) => {
    e.preventDefault()
    const datos = {
      nombre: formulario.nombre,
      categoria: formulario.categoria,
      precio: parseInt(formulario.precio),
      imagen: formulario.imagen || 'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=500&q=80',
    }
    if (editandoId === null) {
      crearProducto({ ...datos, descripcion: 'Producto profesional de audio.' }) // CREAR
    } else {
      actualizarProducto(editandoId, datos) // ACTUALIZAR
    }
    cancelarEdicion()
    alCambiar()
  }

  const empezarEdicion = (p) => {
    setEditandoId(p.id)
    setFormulario({ nombre: p.nombre, categoria: p.categoria, precio: String(p.precio), imagen: p.imagen })
  }

  const cancelarEdicion = () => {
    setEditandoId(null)
    setFormulario(FORMULARIO_VACIO)
  }

  const cambiarStock = (p) => {
    actualizarProducto(p.id, { stock: !p.stock }) // ACTUALIZAR
    alCambiar()
  }

  const borrar = (id) => {
    if (confirm('¿Eliminar producto?')) {
      eliminarProducto(id) // ELIMINAR
      alCambiar()
    }
  }

  const cambiarCampo = (campo) => (e) => setFormulario({ ...formulario, [campo]: e.target.value })

  return (
    <div>
      <h2 className="fw-bold mb-4">Panel Admin</h2>
      <div className="row g-4">
        <div className="col-md-4">
          <div className="card p-3 shadow-sm">
            <h5 className="fw-bold mb-3">{editandoId === null ? 'Nuevo Producto' : 'Editar Producto'}</h5>
            <form onSubmit={guardar}>
              <input type="text" placeholder="Nombre" className="form-control mb-2" required value={formulario.nombre} onChange={cambiarCampo('nombre')} />
              <select className="form-select mb-2" value={formulario.categoria} onChange={cambiarCampo('categoria')}>
                <option value="Guitarras Acústicas">Guitarras Acústicas</option>
                <option value="Guitarras Eléctricas">Guitarras Eléctricas</option>
                <option value="Audio Profesional">Audio Profesional</option>
                <option value="Percusión">Percusión</option>
              </select>
              <input type="number" min="1" placeholder="Precio ($)" className="form-control mb-2" required value={formulario.precio} onChange={cambiarCampo('precio')} />
              <input type="url" placeholder="URL Imagen" className="form-control mb-2" value={formulario.imagen} onChange={cambiarCampo('imagen')} />
              <button type="submit" className="btn btn-warning w-100 fw-bold">
                {editandoId === null ? 'Guardar' : 'Actualizar'}
              </button>
              {editandoId !== null && (
                <button type="button" className="btn btn-outline-secondary w-100 mt-2" onClick={cancelarEdicion}>Cancelar</button>
              )}
            </form>
          </div>
        </div>
        <div className="col-md-8">
          <div className="card p-3 shadow-sm">
            <h5 className="fw-bold mb-3">Inventario ({productos.length})</h5>
            <div className="table-responsive">
              <table className="table table-hover align-middle">
                <thead>
                  <tr>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Acción</th>
                  </tr>
                </thead>
                <tbody>
                  {productos.map(p => (
                    <tr key={p.id}>
                      <td>{p.nombre}</td>
                      <td>${p.precio.toLocaleString('es-CL')}</td>
                      <td>
                        <button className={`btn btn-sm ${p.stock ? 'btn-success' : 'btn-secondary'}`} onClick={() => cambiarStock(p)}>
                          {p.stock ? 'Disponible' : 'Sin stock'}
                        </button>
                      </td>
                      <td>
                        <button className="btn btn-primary btn-sm me-1" onClick={() => empezarEdicion(p)}>Editar</button>
                        <button className="btn btn-danger btn-sm" onClick={() => borrar(p.id)}>Eliminar</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
