import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Routes, Route } from 'react-router-dom'
import Login from './Login'

const mostrar = (setUsuario = jasmine.createSpy()) => {
  render(
    <MemoryRouter initialEntries={['/login']}>
      <Routes>
        <Route path="/login" element={<Login setUsuario={setUsuario} />} />
        <Route path="/admin" element={<h1>Página admin</h1>} />
        <Route path="/productos" element={<h1>Página productos</h1>} />
      </Routes>
    </MemoryRouter>
  )
  return setUsuario
}

const llenar = async (email, clave) => {
  const campos = document.querySelectorAll('input')
  await userEvent.type(campos[0], email)
  await userEvent.type(campos[1], clave)
  await userEvent.click(screen.getByRole('button', { name: /ingresar/i }))
}

describe('Login', () => {
  it('entra como admin con las credenciales correctas', async () => {
    const setUsuario = mostrar()
    await llenar('admin@sonidovivo.cl', 'admin123')
    expect(setUsuario).toHaveBeenCalledWith(jasmine.objectContaining({ rol: 'admin' }))
    expect(await screen.findByText('Página admin')).toBeInTheDocument()
    expect(JSON.parse(localStorage.getItem('usuario_sonido_vivo')).rol).toBe('admin')
  })

  it('entra como cliente con otro correo', async () => {
    const setUsuario = mostrar()
    await llenar('cliente@mail.cl', 'abc')
    expect(setUsuario).toHaveBeenCalledWith(jasmine.objectContaining({ rol: 'cliente' }))
    expect(await screen.findByText('Página productos')).toBeInTheDocument()
  })

  it('una clave incorrecta de admin no da rol admin', async () => {
    const setUsuario = mostrar()
    await llenar('admin@sonidovivo.cl', 'mala')
    expect(setUsuario).toHaveBeenCalledWith(jasmine.objectContaining({ rol: 'cliente' }))
  })

  it('tiene enlace a registro', () => {
    mostrar()
    expect(screen.getByRole('link', { name: /regístrate/i })).toBeInTheDocument()
  })
})
