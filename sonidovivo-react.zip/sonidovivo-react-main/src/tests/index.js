// Punto de entrada de Karma: carga la configuración y todos los archivos *.test.jsx
import './setup'

const contexto = import.meta.webpackContext('..', { recursive: true, regExp: /\.test\.jsx?$/ })
contexto.keys().forEach(contexto)
