import * as JasmineDOM from '@testing-library/jasmine-dom'
import { cleanup } from '@testing-library/react'

// Este paquete viene "envuelto" dos veces al importarlo con webpack, por eso buscamos los matchers adentro
const matchers = JasmineDOM.default?.default ?? JasmineDOM.default ?? JasmineDOM

// Agrega matchers como toBeInTheDocument() a Jasmine
beforeEach(() => {
  jasmine.addMatchers(matchers)
})

// Después de cada test limpiamos la pantalla simulada y el localStorage
afterEach(() => {
  cleanup()
  localStorage.clear()
})
